# 使用手册

## change log
| tag version | change logs | date |
| --- | --- | --- |
| v3.0.0 | 1. 新增资源服务，可进行接口测试<br/>2. 修改了auth-center/docs/sql/init.sql | 2020-01-10 |
| v2.0.0 | 实现自定义登陆页面、自定义授权页面 | 2021-01-07|
| v1.0.0 | 实现初版认证服务器，可进行接口测试<br/>遗留问题：<br/>1. 登录页面加载速度太慢<br/>2. 授权页面太丑 | 2021-01-07 |

## 项目介绍
| 项目名 | 项目介绍 |
| --- | ---|
| [auth-center](auth-center) | 认证服务 |
| [resource-server](resource-server)| 资源服务|
| [register-center](register-center)| 注册中心（未实现）|


未完待续


